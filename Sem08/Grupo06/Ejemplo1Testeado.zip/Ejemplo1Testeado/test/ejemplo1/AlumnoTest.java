/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

import ejemplo1.Alumno;

/**
 *
 * @author Jorge
 */
public class AlumnoTest {
    
    public AlumnoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of calcularPromedio method, of class Alumno.
     */
    @Test
    public void testCalcularPromedio() {
        System.out.println("calcularPromedio");
        Alumno instance = new Alumno("15101090", "J Lo", 14.00, 16.00);
        double expResult = 15.00;
        double result = instance.calcularPromedio();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getCodigo method, of class Alumno.
     */
    @Test
    public void testGetCodigo() {
        System.out.println("getCodigo");
        Alumno instance = new Alumno("15101090", "J Lo", 14.00, 16.00);
        String expResult = "15101090";
        String result = instance.getCodigo();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getNombre method, of class Alumno.
     */
    @Test
    public void testGetNombre() {
        System.out.println("getNombre");
        Alumno instance = new Alumno("15101090", "J Lo", 14.00, 16.00);
        String expResult = "J Lo";
        String result = instance.getNombre();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }

    /**
     * Test of getNotaParcial method, of class Alumno.
     */
    @Test
    public void testGetNotaParcial() {
        System.out.println("getNotaParcial");
        Alumno instance = new Alumno("15101090", "J Lo", 14.00, 16.00);
        double expResult = 14.00;
        double result = instance.getNotaParcial();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
    
    /**
     * Test of getNotaFinal method, of class Alumno.
     */
    @Test
    public void testGetNotaFinal() {
        System.out.println("getNotaFinal");
        Alumno instance = new Alumno("15101090", "J Lo", 14.00, 16.00);
        double expResult = 16.00;
        double result = instance.getNotaFinal();
        assertEquals(expResult, result, 0.0);
        // TODO review the generated test code and remove the default call to fail.
        //fail("The test case is a prototype.");
    }
}
